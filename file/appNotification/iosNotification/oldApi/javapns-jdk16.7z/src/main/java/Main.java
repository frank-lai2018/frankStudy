import org.json.JSONException;

import javapns.Push;
import javapns.communication.exceptions.CommunicationException;
import javapns.communication.exceptions.KeystoreException;
import javapns.notification.PushNotificationBigPayload;
import javapns.notification.PushedNotifications;

public class Main {
	// .p12憑證文件
    private final static String KEY_STORE_PATH = Main.class.getResource("apns.p12").getPath();
	// .p12憑證文件密碼
    private static final String KEYSTOREPASS = ".p12憑證文件密碼";
	// IOS device token
    private static final String token = "0bf8cc232e46338a4a80026d2e1d9360987dad6b4052ae373da45713953be40b";

    public static void main(String[] args) throws JSONException, CommunicationException, KeystoreException {
        //準備推播內容
        PushNotificationBigPayload payload = PushNotificationBigPayload.complex();
        payload.addCustomAlertBody("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        payload.addBadge(9);
        payload.addSound("bingbong.aiff");
        //發送通知給Apns Server
        PushedNotifications payload2 = Push.payload(payload, KEY_STORE_PATH, KEYSTOREPASS, true, token);
        System.out.println(payload2);
    }

}
